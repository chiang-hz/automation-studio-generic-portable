# 網頁資料擷取與Word_JSON_Excel輸出範例

版本：1.0.0

此目錄可匯入 Automation Studio 繼續編輯與執行。匯出內容不含登入密碼、Cookie 或瀏覽器工作站資料。

入口網址：http://127.0.0.1:4173/examples/web-data-demo.html

# 網頁資料擷取與Word_JSON_Excel輸出範例

這是由 Automation Studio 產生的 Playwright TypeScript 專案。

1. 準備 Node.js，於此目錄執行 `npm install` 安裝 package.json 所列套件（啟用 Stealth 的管理模式會包含插件）。
2. 將參數放入 `parameters.json`，或沿用預設值。
3. 執行 `start.bat`。

Stealth 設定保存於 src/workflow.json 的 browser.stealth；僅管理模式生效，CDP 不套用。設定在瀏覽器啟動前載入。

登入驗證、MFA 與驗證碼仍須人工完成。

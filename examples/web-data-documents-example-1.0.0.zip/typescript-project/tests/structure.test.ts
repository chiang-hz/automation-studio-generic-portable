import test from "node:test";
import assert from "node:assert/strict";
import workflow from "../src/workflow.json" with { type: "json" };

test("workflow has an entry URL and enabled steps", () => {
  assert.match(workflow.targetUrl, /^https?:\/\//);
  assert.ok(workflow.steps.some((step) => step.enabled));
});

@echo off
setlocal
if "%NODE_USE_SYSTEM_CA%"=="" set "NODE_USE_SYSTEM_CA=1"
node --experimental-strip-types src\run.ts
if errorlevel 1 pause

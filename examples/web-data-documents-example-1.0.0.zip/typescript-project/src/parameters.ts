export interface WorkflowParameters {

}
